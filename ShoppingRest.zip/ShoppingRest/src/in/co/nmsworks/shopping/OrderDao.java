package in.co.nmsworks.shopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pojo.in.Order;
import com.pojo.in.OrderDetail;

public class OrderDao {

	public static int i=0;
	private static int tab_id=0;
	public List<Order> getAllOrderList(){
		List<Order> orderList = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product", "root" , "Ram@27");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from ord");
			
			orderList = new ArrayList<>();
			while(rs.next()) 
			{
				int Id=rs.getInt(2);
				int Quantity=rs.getInt(3);
				
				orderList.add(new Order( Id, Quantity));
			}
			con.close();
			stmt.close();
			rs.close();
			return orderList;
		}catch (Exception e) {
			System.out.println(e);
		}
					
		return orderList;
	}

	public int createOrder(int Id, int Quantity,int length,int sum,int index) {
		int total = sum;
		OrderDao.tab_id++;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product", "root" , "Ram@27");
			Statement stmt = con.createStatement();
			 String query = "Select price from Product where id = ?";

		     PreparedStatement myStmt = con.prepareStatement(query);
		       myStmt.setInt(1, Id);
		       ResultSet myRs = myStmt.executeQuery();
		       while (myRs.next()) {
		    	   int price = myRs.getInt("price");
		    	   int cost = Quantity * price;
		    	   total = total + (cost);
		    	   System.out.println(total);
		    	   if(index==length-1) {
				       int result = stmt.executeUpdate("insert into ord values("+Restcontroller.orderId+","+length+","+total+")");
				       
		    	   }
		    	   int ord = stmt.executeUpdate("insert into ord_detail values("+OrderDao.tab_id+","+Restcontroller.orderId+","+Id+","+Quantity+","+price+","+cost+")");
                   System.out.println("insert into ord_detail values("+OrderDao.tab_id+","+Restcontroller.orderId+","+Id+","+Quantity+","+price+","+cost+")");		    
		       }

		}catch (Exception e) {
			System.out.println(e);
		}
		return total;
		
	}
	
		
}
