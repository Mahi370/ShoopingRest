package in.co.nmsworks.shopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pojo.in.OrderDetail;


public class OrderDetailDao {
	
public List<OrderDetail> getAllOrderdetailList(){
		List<OrderDetail> orderdetailList = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product", "root" , "Ram@27");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from ord_detail");
			
			orderdetailList = new ArrayList<>();
			while(rs.next()) 
			{
				int Tab_id=rs.getInt(1);
				int Ord_id=rs.getInt(2);
				int Pro_id=rs.getInt(3);
				int Quantity=rs.getInt(4);
				int Price=rs.getInt(5);
				int Totalcost=rs.getInt(6);
				orderdetailList.add(new OrderDetail(Tab_id,Ord_id,Pro_id, Quantity, Price, Totalcost));
			}
			con.close();
			stmt.close();
			rs.close();
			return orderdetailList;
		}catch (Exception e) {
			System.out.println(e);
		}
					
		return orderdetailList;
	}
	
public List<OrderDetail> getOrderdetail(int Ord_id){
	
	List<OrderDetail> getorderdetailList = null;
	
	String sql = "select * from ord_detail where ord_id="+Ord_id;
	
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product", "root" , "Ram@27");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		getorderdetailList = new ArrayList<>();
		while(rs.next())
		{
			int Tab_id=rs.getInt(1);
			int Ordd_id=rs.getInt(2);
			int Pro_id=rs.getInt(3);
			int Quantity=rs.getInt(4);
			int Price=rs.getInt(5);
			int Totalcost=rs.getInt(6);
			getorderdetailList.add(new OrderDetail(Tab_id,Ordd_id,Pro_id, Quantity, Price, Totalcost));
		}
		con.close();
		st.close();
		rs.close();
		return getorderdetailList;
	}catch (Exception e) {
		System.out.println(e);
	}
	return getorderdetailList;
	
}
	
}

