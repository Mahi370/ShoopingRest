package in.co.nmsworks.shopping;

import java.io.IOException;
import java.util.List;


import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.pojo.in.Order;
import com.pojo.in.Product;
import com.pojo.in.OrderDetail;


@Path("/RestController")
public class Restcontroller {
	public static int orderId=999;
	ProductDao productDao = new ProductDao();
	OrderDao orderDao = new OrderDao();
	OrderDetailDao orderdetailDao = new OrderDetailDao();
	
	@GET
	@Path("/viewProduct")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> ViewProduct(){
		
		return productDao.getAllProductList();
	}
	
	@GET
	@Path("/orderDetail")
	@Produces(MediaType.APPLICATION_JSON)
	public List<OrderDetail> OrderDetail(){
		return orderdetailDao.getAllOrderdetailList();
	}
	
	@GET
	@Path("orderDetail/{Ordd_id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<OrderDetail> getOrderdetail(@PathParam("Ordd_id")int Ordd_id)
	{
		return orderdetailDao.getOrderdetail(Ordd_id);	
	}
	
	
	
	@POST
	@Path("/addProduct")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String addProduct (Product product) throws IOException {
		return productDao.addProduct(product.getId(), product.getName(), product.getPrice(), product.getDescripition());		
	}
	
	@POST
	@Path("/createOrder")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public int createOrder(List<Order> orders) throws IOException {
		Order order = new Order();
		System.out.println(orders);
		int sum = 0;
		int length = orders.size();
		Restcontroller.orderId++;
		for(Object ord : orders) {
			System.out.println(ord.toString());
			int index=orders.indexOf(ord);
			sum = orderDao.createOrder(((Order) ord).getId(), ((Order) ord).getQuantity(),length,sum,index);
			
		}
		
		return sum;
		
	}
	
}
	
