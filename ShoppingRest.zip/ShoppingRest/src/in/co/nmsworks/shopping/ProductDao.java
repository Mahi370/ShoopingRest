package in.co.nmsworks.shopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pojo.in.Product;

public class ProductDao {


public List<Product> getAllProductList(){
		
	List<Product> productList = null;
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product", "root" , "Ram@27");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Product");
			
			productList = new ArrayList<>();
			while(rs.next()) 
			{
				int Id=rs.getInt(1);
				String Name=rs.getString(2);
				long Price=rs.getLong(3);
				String Descripition=rs.getString(4);
				
				productList.add(new Product(Id, Name, Price, Descripition));
			}
			con.close();
			stmt.close();
			rs.close();
			return productList;
		}catch (Exception e) {
			System.out.println(e);
		}
					
		return productList;
	}
	
	public String addProduct(int Id, String Name, long Price, String Descripition) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product", "root" , "Ram@27");
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate("insert into Product values("+Id+",'"+Name+"',"+Price+",'"+Descripition+"')");
			
			if (result == 1) {
				return "success";
			}
			stmt.close();
			con.close();
		
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return "fail";
		
	}


	
}
	
	
