package com.pojo.in;

public class OrderDetail {
	int tab_id;
	int ordd_id;
	int pro_id;
	int quantity;
	int price;
	int totalcost;
	
public OrderDetail() {
		
	}

	public OrderDetail(int tab_id,int ordd_id, int pro_id,int quantity,int price,int totalcost) {
		super();
		this.tab_id=tab_id;
		this.ordd_id=ordd_id;
		this.pro_id=pro_id;
		this.quantity=quantity;
		this.price=price;
		this.totalcost =totalcost;
	}

	
	public int getTab_id() {
		return tab_id;
	}

	public void setTab_id(int tab_id) {
		this.tab_id = tab_id;
	}

	public int getOrdd_id() {
		return ordd_id;
	}

	public void setOrdd_id(int ordd_id) {
		this.ordd_id = ordd_id;
	}
	
	public int getPro_id() {
		return pro_id;
	}

	public void setPro_id(int pro_id) {
		this.pro_id = pro_id;
	}
	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(int totalcost) {
		this.totalcost = totalcost;
	}

	@Override
	public String toString() {
		return "{Tab_id="+tab_id+",Ord_id=" + ordd_id + ", Pro_id=" + pro_id + ", Quantity ="
				+ quantity + ", Price=" + price + ", Totalcost=" + totalcost + "}";
	}
}
