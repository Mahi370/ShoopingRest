package com.pojo.in;

public class Product {

	int id;
	String name;
	long price;
	String descripition;
	
public Product() {
	
}

public Product(int id, String name, long price, String descripition) {
	super();
	this.id = id;
	this.name = name;
	this.price = price;
	this.descripition = descripition;
}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	
	public String getDescripition() {
		return descripition;
	}
	public void setDescripition(String descripition) {
		this.descripition = descripition;
	}
	
	@Override
	public String toString() {
		return "Product [Id=" + id + ", Name=" + name + ", Price ="
				+ price + ", Descripition=" + descripition + "]";
		
		/*return "Product [Id=" + id + ", Name=" + name + ", Price ="
		+ price + ", Descripition=" + descripition + "]";*/
	}
	

}
